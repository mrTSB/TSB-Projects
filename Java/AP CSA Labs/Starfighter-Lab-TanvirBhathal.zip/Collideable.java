public interface Collideable<T>{
  boolean didCollide(T other);
}