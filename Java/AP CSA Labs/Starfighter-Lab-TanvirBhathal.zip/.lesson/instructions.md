# Starfighter Lab

## Description
The requirements for each activity are described in the Starfighter Lag Project Guide and in the corresponding Activity Worksheet docs in Google Classroom.  

## Submission
* Submit all code in this replit project
* Complete the corresponding Activity Worksheets in Google Classroom
* Create a video of the completed game being played (see reqs in Google Classroom)

