public class Main
{

  // a stub for replit to call the main method in TheGame
  public static void main( String args[] )
  {
    //BlockTestOne.main(args);
    //BlockTestTwo.main(args);
    //BallTestOne.main(args);
    //PaddleTestOne.main(args);
    //Tester.main(args);
    TheGame.main(args);
    //customTest.main(args);
  }

}